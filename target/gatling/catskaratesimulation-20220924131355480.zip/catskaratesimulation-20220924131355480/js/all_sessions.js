allUsersData = {
    
color: '#FF9D00',
name: 'Active Users',
data: [
  [1664025236000,3],[1664025237000,4],[1664025238000,4],[1664025239000,4],[1664025240000,3]
],
tooltip: { yDecimals: 0, ySuffix: '', valueDecimals: 0 }
    , zIndex: 20
    , yAxis: 1
};