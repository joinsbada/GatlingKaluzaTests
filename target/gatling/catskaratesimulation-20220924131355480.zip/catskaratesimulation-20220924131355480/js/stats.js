var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "50",
        "ok": "50",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1103",
        "ok": "1103",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "123",
        "ok": "123",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "168",
        "ok": "168",
        "ko": "-"
    },
    "percentiles1": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "percentiles2": {
        "total": "97",
        "ok": "97",
        "ko": "-"
    },
    "percentiles3": {
        "total": "419",
        "ok": "419",
        "ko": "-"
    },
    "percentiles4": {
        "total": "819",
        "ok": "819",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 49,
    "percentage": 98
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "10",
        "ok": "10",
        "ko": "-"
    }
},
contents: {
"req_get--journey-jo-d2f5f": {
        type: "REQUEST",
        name: "GET /journey/journeyresults/Victoria/to/Paddington?mode=bus%2Ctube%2Ccoach&dateTime=2022-10-22T13%3A15%3A00&journeyPreference=LeastTime&bikeProficiency=Easy&walkingSpeed=Slow&dateTimeType=Arriving",
path: "GET /journey/journeyresults/Victoria/to/Paddington?mode=bus%2Ctube%2Ccoach&dateTime=2022-10-22T13%3A15%3A00&journeyPreference=LeastTime&bikeProficiency=Easy&walkingSpeed=Slow&dateTimeType=Arriving",
pathFormatted: "req_get--journey-jo-d2f5f",
stats: {
    "name": "GET /journey/journeyresults/Victoria/to/Paddington?mode=bus%2Ctube%2Ccoach&dateTime=2022-10-22T13%3A15%3A00&journeyPreference=LeastTime&bikeProficiency=Easy&walkingSpeed=Slow&dateTimeType=Arriving",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "69",
        "ok": "69",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "524",
        "ok": "524",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "132",
        "ok": "132",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "132",
        "ok": "132",
        "ko": "-"
    },
    "percentiles1": {
        "total": "88",
        "ok": "88",
        "ko": "-"
    },
    "percentiles2": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "percentiles3": {
        "total": "344",
        "ok": "344",
        "ko": "-"
    },
    "percentiles4": {
        "total": "488",
        "ok": "488",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    }
}
    },"req_get--journey-jo-52753": {
        type: "REQUEST",
        name: "GET /journey/journeyresults/Victoria/to/Blackfriars?mode=tube%2Ccoach&dateTime=2022-11-22T11%3A15%3A00&journeyPreference=LeastInterchange&bikeProficiency=Moderate&walkingSpeed=Average&dateTimeType=Departing",
path: "GET /journey/journeyresults/Victoria/to/Blackfriars?mode=tube%2Ccoach&dateTime=2022-11-22T11%3A15%3A00&journeyPreference=LeastInterchange&bikeProficiency=Moderate&walkingSpeed=Average&dateTimeType=Departing",
pathFormatted: "req_get--journey-jo-52753",
stats: {
    "name": "GET /journey/journeyresults/Victoria/to/Blackfriars?mode=tube%2Ccoach&dateTime=2022-11-22T11%3A15%3A00&journeyPreference=LeastInterchange&bikeProficiency=Moderate&walkingSpeed=Average&dateTimeType=Departing",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "61",
        "ok": "61",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "516",
        "ok": "516",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "117",
        "ok": "117",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "133",
        "ok": "133",
        "ko": "-"
    },
    "percentiles1": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "percentiles2": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "percentiles3": {
        "total": "329",
        "ok": "329",
        "ko": "-"
    },
    "percentiles4": {
        "total": "479",
        "ok": "479",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    }
}
    },"req_get--journey-jo-6ba4d": {
        type: "REQUEST",
        name: "GET /journey/journeyresults/Victoria/to/Vauxhall?mode=tube%2Cbus&dateTime=2022-07-22T10%3A15%3A00&journeyPreference=LeastWalking&bikeProficiency=Fast&walkingSpeed=Fast&dateTimeType=Arriving",
path: "GET /journey/journeyresults/Victoria/to/Vauxhall?mode=tube%2Cbus&dateTime=2022-07-22T10%3A15%3A00&journeyPreference=LeastWalking&bikeProficiency=Fast&walkingSpeed=Fast&dateTimeType=Arriving",
pathFormatted: "req_get--journey-jo-6ba4d",
stats: {
    "name": "GET /journey/journeyresults/Victoria/to/Vauxhall?mode=tube%2Cbus&dateTime=2022-07-22T10%3A15%3A00&journeyPreference=LeastWalking&bikeProficiency=Fast&walkingSpeed=Fast&dateTimeType=Arriving",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "61",
        "ok": "61",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "196",
        "ok": "196",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "94",
        "ok": "94",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "38",
        "ok": "38",
        "ko": "-"
    },
    "percentiles1": {
        "total": "80",
        "ok": "80",
        "ko": "-"
    },
    "percentiles2": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "percentiles3": {
        "total": "158",
        "ok": "158",
        "ko": "-"
    },
    "percentiles4": {
        "total": "188",
        "ok": "188",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    }
}
    },"req_get--journey-jo-a767b": {
        type: "REQUEST",
        name: "GET /journey/journeyresults/Victoria/to/Farringdon?mode=tube%2Ccoach&dateTime=2022-12-22T13%3A15%3A00&journeyPreference=LeastTime&bikeProficiency=Fast&walkingSpeed=Fast&dateTimeType=Departing",
path: "GET /journey/journeyresults/Victoria/to/Farringdon?mode=tube%2Ccoach&dateTime=2022-12-22T13%3A15%3A00&journeyPreference=LeastTime&bikeProficiency=Fast&walkingSpeed=Fast&dateTimeType=Departing",
pathFormatted: "req_get--journey-jo-a767b",
stats: {
    "name": "GET /journey/journeyresults/Victoria/to/Farringdon?mode=tube%2Ccoach&dateTime=2022-12-22T13%3A15%3A00&journeyPreference=LeastTime&bikeProficiency=Fast&walkingSpeed=Fast&dateTimeType=Departing",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "64",
        "ok": "64",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "85",
        "ok": "85",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "70",
        "ok": "70",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "6",
        "ok": "6",
        "ko": "-"
    },
    "percentiles1": {
        "total": "69",
        "ok": "69",
        "ko": "-"
    },
    "percentiles2": {
        "total": "71",
        "ok": "71",
        "ko": "-"
    },
    "percentiles3": {
        "total": "80",
        "ok": "80",
        "ko": "-"
    },
    "percentiles4": {
        "total": "84",
        "ok": "84",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 10,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    }
}
    },"req_get--journey-jo-07c68": {
        type: "REQUEST",
        name: "GET /journey/journeyresults/Victoria/to/Whitechapel?mode=coach%2Cnational-rail&dateTime=2022-10-22T07%3A15%3A00&journeyPreference=LeastWalking&bikeProficiency=Moderate&walkingSpeed=Slow&dateTimeType=Arriving",
path: "GET /journey/journeyresults/Victoria/to/Whitechapel?mode=coach%2Cnational-rail&dateTime=2022-10-22T07%3A15%3A00&journeyPreference=LeastWalking&bikeProficiency=Moderate&walkingSpeed=Slow&dateTimeType=Arriving",
pathFormatted: "req_get--journey-jo-07c68",
stats: {
    "name": "GET /journey/journeyresults/Victoria/to/Whitechapel?mode=coach%2Cnational-rail&dateTime=2022-10-22T07%3A15%3A00&journeyPreference=LeastWalking&bikeProficiency=Moderate&walkingSpeed=Slow&dateTimeType=Arriving",
    "numberOfRequests": {
        "total": "10",
        "ok": "10",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1103",
        "ok": "1103",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "309",
        "ok": "309",
        "ko": "-"
    },
    "percentiles1": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "percentiles2": {
        "total": "92",
        "ok": "92",
        "ko": "-"
    },
    "percentiles3": {
        "total": "742",
        "ok": "742",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1031",
        "ok": "1031",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9,
    "percentage": 90
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2",
        "ok": "2",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
